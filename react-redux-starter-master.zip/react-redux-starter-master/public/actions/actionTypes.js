export const TEXT_CHANGED = 'TEXT_CHANGED';
